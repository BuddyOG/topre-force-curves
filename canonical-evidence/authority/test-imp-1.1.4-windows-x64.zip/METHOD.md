# Test importer method, version 1.1.4

This executable is an intake gate for new raw dome tests. It does not replace
the canonical Dome Lab generator, infer product identity, or establish a
perceptual model.

The executable identity is `1.1.4` / `metrics-v4.2` /
`intake-qc-v1.4`. The metrics method is unchanged. The intake-policy increment
adds the retained-cohort RAMP repeatability review described below; it does not
alter any metric scalar, per-run validity decision, or Fc/xc retention result.

The 14 reported curve metrics implement metrics-v4.2: a centered seven-sample
arithmetic moving mean with shrinking edges supplies force-shape landmarks;
raw calibrated force supplies the trapezoidal work integrals. Metrics are
computed independently for each run. Metrics-v4.2 preserves the existing
metric values for current accepted data and repairs the RAMP event domain for
future edge cases.

The per-run coherence gate is bidirectional: terminal landmarks, detected
force-wall travel/work, STEEPEST DROP endpoints, RAMP evidence, and each
declared positive-domain/null flag must agree. Equal STEEPEST DROP slopes keep
the exact global-maximum scalar and audit the earliest interval within
1e-12 gf/mm of that maximum. Aggregate means are not subjected to per-run
nonlinear identities.

Early RAMP-null states are audit-terminal: baseline-band incomplete,
baseline unavailable, and reference-band overlap require all four crossing
counters to remain zero. A nonzero all-crossing or eligible-crossing counter
contradicts those reasons and fails the per-run coherence gate.

## Intake order

1. Parse and trajectory integrity.
2. Signal-integrity checks.
3. Speed/cadence classification: preferred-band flags, then hard guards.
4. Fatal per-run landmark validity plus metric-local null classification.
5. Conservative detection of two replicate-supported curve populations.
6. Median-centered replicate filtering.
7. If at least three retained runs have numeric RAMP, apply the nonfatal RAMP
   repeatability review.
8. Require at least two retained runs.
9. Any separate RAMP-review acknowledgement, ordinary operator confirmation,
   and transactional copy.

## Signal-discontinuity policy

Signal-integrity checks use raw calibrated force rather than the smoothed
landmark curve. Within the force-shape domain from 0.10 mm through the lesser
of 3.40 mm and detected travel:

* On the press stroke only, an adjacent 0.005 mm step with an absolute force
  change greater than 5.0 gf is fatal. Equality passes.
* On both press and return, a sample whose absolute residual from the midpoint
  of its immediate neighbors is greater than 5.0 gf is fatal. Equality passes.

The phase split is deliberate. A repeatable dome-release transition can
produce a steep, multi-sample return step without indicating data corruption.
The bidirectional local-residual test still rejects an isolated return sample,
while press-stroke adjacent jumps remain guarded because they can corrupt the
collapse landmarks used for retention.

## Speed policy

The full-cycle effective speed is

`2(max(x)-min(x)) / ((t_last-t_first)/1000)`.

The following are preferred targets. Missing any one is always reported as a
`speed flag`, but does not by itself exclude an otherwise valid run:

* full-cycle effective speed 0.1445-0.1500 mm/s;
* collapse-local median speed 0.1445-0.1520 mm/s;
* overall median sample interval 33-35 ms;

The hard acquisition guards are:

* full-cycle effective speed 0.1400-0.1530 mm/s;
* collapse-local median speed 0.1400-0.1550 mm/s;
* the original normal-cadence proportions remain hard requirements: at least
  95% over the full press, 98% over the final 0.25 mm before collapse, and 95%
  from collapse to valley;
* no timing dwell over twice the run median in the final 0.25 mm before collapse;
* no 20-step sustained press block outside 0.135-0.160 mm/s;
* fewer than 10 intervals above three times the run median.

Thus a 33 ms or 35 ms uniform cadence can be accepted with a visible flag even
when its full-cycle average falls just outside 0.1445-0.1500 mm/s. This is a
deliberate correction: preferred-band misses are evidence to disclose, not an
automatic reason to discard one or two otherwise coherent replicates. Runs
outside the hard envelope or with grossly nonuniform timing remain ineligible.

Isolated pauses outside the collapse approach can remain a visible note when
the spatial grid and other gates are intact. Accepted flagged runs participate
in mixed-population detection and median-centered replicate filtering exactly
like preferred-speed runs. At least two matching retained runs are still
required.

## Replicate policy

For individually acceptable runs, conventional medians `Fc*` and `xc*` are
computed. A run is retained when both conditions hold:

`abs(Fc-Fc*) <= max(1.0 gf, 0.02*abs(Fc*))`

`abs(xc-xc*) <= 0.05 mm`

Equality passes. This is deliberately group-centered, not an all-pairs rule.
The known four-run Carrots cohort has two close force pairs but all four remain
within 0.677 gf of the common median and correctly pass together.

Mixed-population detection uses Fc, xc, SNAP, and normalized drop rate after
the structural, protocol, and fatal landmark gates. A metric-local RAMP,
force-wall/work, or STEEPEST DROP null cannot hide a second population. A
singleton is treated as an outlier/retest, not as proof of another physical
dome; two compact supported groups stop import.

## Retained-cohort RAMP repeatability review

This intake-policy review runs only after all per-run QC and Fc/xc replicate
retention, and only when no mixed population has been detected. Let `R_i` be a
numeric metrics-v4.2 RAMP from a retained run and let `R*` be the conventional
median of all numeric retained-run RAMP values. At least three such numeric
values and a positive finite median are required. Null RAMP values do not count
toward the minimum and cannot receive this warning.

A retained run is marked `ACCEPT + RAMP REVIEW` exactly when

`abs(R_i-R*) / abs(R*) > 0.10`.

Equality at 10% passes. A floating-point equality guard of 1e-12 is used only
to keep a mathematically exact boundary from becoming a false strict-greater-
than result. The displayed evidence includes `R_i`, `R*`, the signed percentage
difference with above/below direction, the absolute percentage difference, and
the greater-than-10% threshold, all with enough precision to distinguish a
near-boundary warning from equality.

This review never changes `retained`, never omits a run, never changes the
cohort median used for Fc/xc filtering, and never changes any metrics-v4.2
value. It is an operator-review trigger for a shape difference that can be real
mechanical variation rather than acquisition failure. If any run is marked,
the interactive workflow requires the exact separate phrase `RAMP REVIEW`
before it proceeds to the existing exact `IMPORT` confirmation. The hidden
automation option `--yes` does not imply that acknowledgement; a warned
noninteractive import additionally requires explicit `--ack-ramp-review`.

The 10% threshold is a provisional empirical review guardrail. It is not an
instrument-uncertainty bound, a validated statistical-outlier test, a dome
failure criterion, or a scientific rejection rule. It must be reassessed as
the controlled repeatability dataset grows.

## Metric definitions and local nulls

DROP RATE is `(Fc-Fv)/(xv-xc)`: the positive magnitude of the net
peak-to-valley spatial secant in gf/mm. It is not a time rate, a mean of local
negative slopes, or a perceptual sharpness score. Its numerical formula and
sign are unchanged from metrics-v4.1.

Travel is detected force-wall onset, an operational bottom-out proxy. If no
qualifying wall is found, travel and press work to the wall are null with
`bottomout_not_found`; the raw run can still pass the other intake gates.

RAMP is the chosen post-seating, baseline-relative 10-90 force-rise secant.
Its executable constants are: seating endpoint 0.05 mm; inclusive reference
band 0.05-0.15 mm with at least three samples and complete press-trace coverage
of both configured bounds (samples need not land exactly on either bound);
fractions 0.10 and 0.90; minimum rise 1 gf; minimum crossing span 0.02 mm; and
coordinate comparison tolerance 1e-9 mm. Collapse must occur above 0.15 mm by
more than the tolerance. Every upward piecewise-linear crossing through the
collapse is interpolated, crossings below the post-seating domain are removed,
and the last eligible crossing for each threshold is selected. The required
order is `0.05 <= x10 < x90 <= xc`. RAMP failure is metric-local and does not
change structural eligibility, runfilter retention, or unrelated outputs.
An incomplete press span over the configured reference band is reported as
`ramp_baseline_band_incomplete`; too few in-band samples or inadequate force
rise is `ramp_baseline_unavailable`.

These thresholds are provisional engineering guardrails calibrated against the
currently accepted specimens. They must be revisited as the repeatability and
controlled-rate datasets grow. They are not uncertainty estimates,
manufacturer tolerances, or validated tactile-perception boundaries.
