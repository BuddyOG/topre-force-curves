TOPRE DOME TEST IMPORTER 1.1.4
================================

PURPOSE
-------
test-imp.exe checks one folder of raw Dome Lab CSV runs, omits failed or
nonmatching runs, and (only after your confirmation) creates a new dome folder
inside your local topre-force-curves Git repository.

This release identifies its curve calculations as metrics-v4.2 and its intake
rules as intake-qc-v1.4.

RUNTIME PREREQUISITES
---------------------
* Windows 10 or Windows 11, 64-bit.
* Your existing local repository at:
  D:\Documents\GitHub\topre-force-curves

That is all. The finished EXE is self-contained. You do NOT need to install
Python, Bash, pip, PyInstaller, or any Python packages to run it. It does not
need a network connection.

SETUP FOR EACH DOME
-------------------
1. Create a temporary folder outside the GitHub repository.
2. Put test-imp.exe and only that dome's raw DataLog_*.csv files in it.
   Unrelated files are ignored, but never mix tests from different domes.
3. Open Command Prompt.
4. Run, for example:

   "C:\path\to\test folder\test-imp.exe" "Astro_Domes_160g"

The dome name becomes the destination folder name. It must be one safe Windows
folder name, not a path.

WHAT IT CHECKS
--------------
* Exact five-column bench CSV structure and finite numeric data.
* Complete, monotonic 0.005 mm / 8-step press-and-return trajectory.
* Correct duplicate turnaround, origin, return endpoint, and stroke span.
* Timestamp order, sustained cadence changes, and acquisition pauses.
* Preferred aggregate, collapse-local, and median-cadence targets, with every
  miss visibly flagged.
* A wider hard speed/cadence envelope that rejects materially slow, fast, or
  unstable acquisitions without discarding isolated marginal misses.
* ADC dropout, negative readings outside the unloaded endpoint, saturation,
  stale force samples, abrupt press-stroke adjacent-step discontinuities, and
  isolated local-residual spikes on either press or return.
* Valid metrics-v4.2 mechanical collapse and valley landmarks, detected
  force-wall onset, work, drop, and post-seating RAMP.
* Metric-local nulls are reported without discarding an otherwise usable run:
  a missing force wall affects travel/work-to-wall, a short drop interval
  affects STEEPEST DROP, and a RAMP failure affects RAMP only. Structural,
  protocol, and collapse/valley event barriers remain fatal.
* More than one replicate-supported curve population in the source folder.
* Replicate agreement around the conventional median collapse force and
  collapse position. At least two accepted matching runs are required.
* Retained-run RAMP repeatability. When at least three retained runs have a
  numeric RAMP, a value more than 10% above or below their median is marked
  ACCEPT + RAMP REVIEW. Equality at 10% passes. This is a nonfatal warning,
  not an omission rule.

The preferred full-cycle speed is 0.1445-0.1500 mm/s. A run just outside that
band is marked PASS + SPEED and may still be imported when it stays inside the
hard 0.1400-0.1530 mm/s envelope and passes integrity, the original strict
regional-cadence requirements, metrics, and replicate agreement. This prevents one or two marginal speed
misses from being automatically discarded. Genuinely slow acquisitions such
as the previously observed ~0.111 mm/s cohort still fail.

The force acceptance band is max(1.0 gf, 2% of the group median), and the
collapse-position band is +/-0.05 mm. The speed envelopes and replicate bands
are versioned empirical intake rules, not instrument uncertainty limits or
claims about human perception.

The raw-force adjacent-step discontinuity limit is greater than 5.0 gf per
0.005 mm and applies only to the press stroke. Equality passes. A smooth dome
release can legitimately cross that slope on return, so a steep return step is
not fatal by itself. The independent local-residual guard remains active on
both press and return; an isolated sample more than 5.0 gf from the midpoint
of its neighbors still fails. This keeps return-stroke corruption visible
without rejecting a repeatable multi-sample release transition.

IMPORT BEHAVIOR
---------------
Before writing, the program shows every file's collapse force, position, SNAP,
DROP RATE, NDR, post-seating RAMP, detected force-wall position, speed, median
sample interval, QC result, and the exact reason for every omission. If it
detects two supported curve populations, it stops and asks you to separate
them into different folders.

DROP RATE is the positive magnitude of the net peak-to-valley force-travel
secant in gf/mm. It is not a time rate, mean local slope, or perceptual
sharpness score. The force-wall event is an operational bottom-out proxy, not
an independent observation of physical contact.

Accepted marginal-speed runs remain conspicuous: each receives PASS + SPEED,
its exact target-band miss is printed, the cohort summary counts speed flags,
and a SPEED NOTICE appears immediately before the IMPORT prompt.

A retained RAMP warning is also conspicuous. The table decision reads
ACCEPT + RAMP REVIEW, and the detail shows the run's RAMP, retained-run median,
signed percentage difference, absolute percentage difference, and the strict
greater-than-10% threshold. The run remains included because RAMP disagreement
alone is not evidence of a failed acquisition. Before any destination checks
or copy, type the separate exact phrase RAMP REVIEW. Pressing Enter cancels
without writing. After acknowledgement, the normal IMPORT confirmation is
still required.

The 10% value is a provisional empirical review threshold. It is not an
instrument-uncertainty statement, a validated statistical-outlier test, or an
automatic scientific rejection rule. It should be revisited as controlled
repeatability data accumulate.

If at least two matching runs remain, type IMPORT at the confirmation prompt.
The program then:

* creates D:\Documents\GitHub\topre-force-curves\<Dome_Name>;
* copies accepted CSVs byte-for-byte;
* renumbers them densely as DataLog_1.csv, DataLog_2.csv, ...;
* gives the highest-numbered output the current local minute;
* makes each earlier file exactly five minutes older;
* verifies every copied SHA-256 hash before completing.

The source CSVs are never changed. An existing destination is never overwritten.
The program does not run Git, stage files, commit, push, edit the workbook, or
modify Dome Lab JSON. Review the created folder and perform Git operations
manually.

AUTOMATION SAFETY
-----------------
The internal --yes option approves the ordinary IMPORT confirmation only. It
never acknowledges a RAMP review warning. A warned noninteractive run stops
without writing unless --ack-ramp-review is also supplied explicitly. Thus a
reviewed automation command must contain both options; --ack-ramp-review by
itself only replaces the RAMP REVIEW phrase and does not replace IMPORT.

SAFETY / WINDOWS NOTICE
-----------------------
This is an unsigned local executable. Windows may show a SmartScreen notice.
Do not disable Microsoft Defender. Run the file only when its SHA-256 matches
the value supplied with this build.

OPTIONAL: BUILDING FROM SOURCE
------------------------------
This is not needed to use test-imp.exe. Developers can build it from PowerShell:

  py -3.14 -m venv .build-venv
  .\.build-venv\Scripts\python.exe -m pip install PyInstaller==6.21.0
  .\build.ps1 -Python .\.build-venv\Scripts\python.exe

No Bash setup is required on Windows.
